# AURA diagnosis input mode: prompt_libre
# AURA input receipt: 883ba416bbecda495c3a5f3c72dfa0c78d225d5ff501b64585b442f13fcbeafb
# AURA prompt hash: 21db7495d96ae4d98618b5cd7d0888cd95f2ae122f9c8c20a5b72b197f9359b0
# AURA input hash: 44a197935a06109c926a77b59a07848cca6a2757809f45640f2b13b19912d385
# AURA evidence envelope: env:84f35ac4e828fafaaea2af5469a405700881c1082ed31d221164bfcf54d480b0

import pandas as pd
import numpy as np

_c = {
    "col:66c132b9f764eca1": "id",
    "col:c48ed5501a3f61e9": "nombre",
    "col:14a06a875d2805a1": "edad",
    "col:3ccf050c2a6ae5c6": "salario",
    "col:534000c8bf517b29": "email",
    "col:715d2723c97715b7": "departamento",
    "col:623e34a359a89dd3": "fecha_ingreso",
    "col:f9b45ca6934a8296": "estado",
    "col:e7b2c5a4df357066": "ip_acceso"
}

def clean_dataset(df):
    df_clean = df.copy()
    df_clean = df_clean.drop_duplicates(keep="first").copy()
    df_clean[_c["col:14a06a875d2805a1"]] = df_clean[_c["col:14a06a875d2805a1"]].replace(["", "n/a", "N/A", "na", "NA", "null", "NULL", "none", "None", "?", "-", "--", "...", "NaN", "NAN", "nan", "N/a"], np.nan)
    df_clean[_c["col:534000c8bf517b29"]] = df_clean[_c["col:534000c8bf517b29"]].replace(["", "n/a", "N/A", "na", "NA", "null", "NULL", "none", "None", "?", "-", "--", "...", "NaN", "NAN", "nan", "N/a"], np.nan)
    df_clean[_c["col:f9b45ca6934a8296"]] = df_clean[_c["col:f9b45ca6934a8296"]].replace(["", "n/a", "N/A", "na", "NA", "null", "NULL", "none", "None", "?", "-", "--", "...", "NaN", "NAN", "nan", "N/a"], np.nan)
    return df_clean
