# AURA - Paquete completo de evidencia

Run ID: audit-1784057358297
Report ID: diag-report-c6dc55d6
Dataset SHA-256: 4e7d358f2141c6463146417a66f1c2312c7c3cdf6a39005780c92b061ff7ac49
Recibo diagnóstico: 18963b04fa298d5720b35f4e993de6a851c43851475a461281e4a0741e354230

Este ZIP reúne los artefactos de una misma sesión para revisión, auditoría y reproducción.
No incluye el CSV original ni API keys. El dataset se identifica por su SHA-256.
Puede incluir muestras visibles de los hallazgos y del payload; revísalo antes de compartirlo fuera del entorno autorizado.
Las capturas SVG son vistas reproducibles generadas desde los contratos; no son screenshots del navegador.
manifest.json contiene el SHA-256 y tamaño de cada archivo incluido.

## Datasets

- El CSV original (source.csv) NO está incluido en este ZIP; solo se conserva su SHA-256.
- corrected.csv NO está incluido: esta corrida no completó una ejecución Python + reauditoría verificadas.
- corrected.csv es el resultado de la remediación y puede conservar datos personales (PII); trátalo con el mismo cuidado que el original antes de compartirlo.
