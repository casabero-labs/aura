# AURA - Paquete completo de evidencia

Run ID: audit-1791210641255
Report ID: diag-report-2ae72913
Dataset SHA-256: 23f713bb0be77e6b98690e1b91795e237686a71ee3ca72f5c9890214e011d21f
Recibo diagnóstico: cd12ff95910a2b5541a56038e801453edab99c1795cfa3ef534f94bb559f256f

Este ZIP reúne los artefactos de una misma sesión para revisión, auditoría y reproducción.
No incluye el CSV original ni API keys. El dataset se identifica por su SHA-256.
Puede incluir muestras visibles de los hallazgos y del payload; revísalo antes de compartirlo fuera del entorno autorizado.
Las capturas SVG son vistas reproducibles generadas desde los contratos; no son screenshots del navegador.
manifest.json contiene el SHA-256 y tamaño de cada archivo incluido.

## Datasets

- El CSV original (source.csv) NO está incluido en este ZIP; solo se conserva su SHA-256.
- corrected.csv NO está incluido: esta corrida no completó una ejecución Python + reauditoría verificadas.
- corrected.csv es el resultado de la remediación y puede conservar datos personales (PII); trátalo con el mismo cuidado que el original antes de compartirlo.
