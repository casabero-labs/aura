# AURA - Paquete completo de evidencia

Run ID: audit-1791208585679
Report ID: diag-report-58ab503d
Dataset SHA-256: 94c3207b84a75519225cfff24214257d6f222a5c08bf3d71355e373a1e2308a2
Recibo diagnóstico: 25d267a03933450bf95c8dc65746c9d08cf831914102458650ef461db616f0d4

Este ZIP reúne los artefactos de una misma sesión para revisión, auditoría y reproducción.
No incluye el CSV original ni API keys. El dataset se identifica por su SHA-256.
Puede incluir muestras visibles de los hallazgos y del payload; revísalo antes de compartirlo fuera del entorno autorizado.
Las capturas SVG son vistas reproducibles generadas desde los contratos; no son screenshots del navegador.
manifest.json contiene el SHA-256 y tamaño de cada archivo incluido.

## Datasets

- El CSV original (source.csv) NO está incluido en este ZIP; solo se conserva su SHA-256.
- corrected.csv NO está incluido: esta corrida no completó una ejecución Python + reauditoría verificadas.
- corrected.csv es el resultado de la remediación y puede conservar datos personales (PII); trátalo con el mismo cuidado que el original antes de compartirlo.
