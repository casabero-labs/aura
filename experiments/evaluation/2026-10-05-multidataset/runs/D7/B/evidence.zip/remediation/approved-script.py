# AURA diagnosis input mode: smart_sample
# AURA input receipt: 25d267a03933450bf95c8dc65746c9d08cf831914102458650ef461db616f0d4
# AURA prompt hash: c2ebef42c5aff8d95a948daea8a38e66643b4125a250b95f8c63443c4991ca42
# AURA input hash: 604cc8a9d144533c60dd45b2743f903c19d27461f31f1d777306a9a11e54dccb
# AURA evidence envelope: env:029741620ba1b59939d23e945c9948982973ed047ce984ab7efd06c4bfe4b33a

import pandas as pd
import numpy as np

_c = {
    "col:66c132b9f764eca1": "id",
    "col:96892afc6657dc38": "ciudad",
    "col:148f59a4e6320451": "importe",
    "col:407bb8254eeabe02": "codigo",
    "col:a71ab97511ea781f": "nota"
}

def clean_dataset(df):
    df_clean = df.copy()
    df_clean[_c["col:407bb8254eeabe02"]] = pd.to_numeric(
        df_clean[_c["col:407bb8254eeabe02"]].astype("string").str.replace(",", ".", regex=False),
        errors="coerce",
    )
    return df_clean
