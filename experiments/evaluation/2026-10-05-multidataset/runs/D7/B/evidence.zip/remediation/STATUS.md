# Estado de remediación

Estado: reaudited

La reauditoría usa el mismo motor determinista de AURA y no sustituye validación de dominio
Una mejora del score no prueba por sí sola la corrección de negocio.
