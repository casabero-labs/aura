# Estado de remediación

Estado: not_run

El análisis fue completado, pero no se ejecutó una remediación sobre el dataset
