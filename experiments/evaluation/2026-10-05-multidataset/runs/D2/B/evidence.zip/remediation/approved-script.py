# AURA diagnosis input mode: smart_sample
# AURA input receipt: a06580f55816ceaaad7105c1a95344d3a9111a1b8e41fc907c900231f1700b47
# AURA prompt hash: 0a131dd1c4c935332d4f84bee2695d8d3959eabb2a06f51d3da5a8755896c0c8
# AURA input hash: 4fdbd0d3cd1cd8d446075dc19006b91d95aa2af68fc785f02601cbbf164449fc
# AURA evidence envelope: env:f5f578d697c301328d671b3205041d247b7e65b35c42db6961c1e5599a3d8eb3

import pandas as pd
import numpy as np

_c = {
    "col:66c132b9f764eca1": "id",
    "col:c48ed5501a3f61e9": "nombre",
    "col:14a06a875d2805a1": "edad",
    "col:3ccf050c2a6ae5c6": "salario",
    "col:534000c8bf517b29": "email",
    "col:715d2723c97715b7": "departamento",
    "col:623e34a359a89dd3": "fecha_ingreso",
    "col:f9b45ca6934a8296": "estado",
    "col:e7b2c5a4df357066": "ip_acceso"
}

def clean_dataset(df):
    df_clean = df.copy()
    df_clean = df_clean.drop_duplicates(keep="first").copy()
    df_clean[_c["col:14a06a875d2805a1"]] = df_clean[_c["col:14a06a875d2805a1"]].replace(["", "n/a", "N/A", "na", "NA", "null", "NULL", "none", "None", "?", "-", "--", "...", "NaN", "NAN", "nan", "N/a"], np.nan)
    df_clean[_c["col:534000c8bf517b29"]] = df_clean[_c["col:534000c8bf517b29"]].replace(["", "n/a", "N/A", "na", "NA", "null", "NULL", "none", "None", "?", "-", "--", "...", "NaN", "NAN", "nan", "N/a"], np.nan)
    df_clean[_c["col:f9b45ca6934a8296"]] = df_clean[_c["col:f9b45ca6934a8296"]].replace(["", "n/a", "N/A", "na", "NA", "null", "NULL", "none", "None", "?", "-", "--", "...", "NaN", "NAN", "nan", "N/a"], np.nan)
    return df_clean
